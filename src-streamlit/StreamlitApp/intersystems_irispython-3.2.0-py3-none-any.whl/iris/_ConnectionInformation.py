import iris._Constant

class _ConnectionInformation(object):

    def __init__(self):
        self.protocol_version = iris._Constant._Constant.PROTOCOL_VERSION
        self._is_unicode = True
        self._compact_double = False
        self._locale = "latin-1"
        self._delimited_ids = 0
        self._server_version = ""
        self._server_version_major = 0
        self._server_version_minor = 0
        self._iris_install_dir = ""
        self._server_job_number = -1

    def _set_server_locale(self, locale):
        self._locale = self._map_server_locale(locale)

    def _parse_server_version(self, server_version):
        split_1 = server_version.split("|")
        self._server_version = split_1[0]
        if len(split_1)>1: self._iris_install_dir = split_1[1]
        if self._server_version.find("Version") > 0:
            version = server_version[server_version.find("Version")+8:]
            self._server_version_major = version.split(".")[0]
            self._server_version_minor = version.split(".")[1]
        return

    @staticmethod
    def _map_server_locale(locale):
        # we need to map IRIS locale literals to Python locale literals
        if locale == "Unicode" or locale.upper() == "LATIN1":
            return "latin_1"
        if locale.upper() == "LATIN2":
            return "iso8859_2"
        if locale.upper() == "LATINC":
            return "iso8859_5"
        if locale.upper() == "LATINA":
            return "iso8859_6"
        if locale.upper() == "LATING":
            return "iso8859_7"
        if locale.upper() == "LATINH":
            return "iso8859_8"
        if locale.upper() == "LATINT":
            return "iso8859_11"
        if locale.upper() == "LATIN9":
            return "iso8859_15"
        if locale.upper() == "CP1250":
            return "cp1250"
        if locale.upper() == "CP1251":
            return "cp1251"
        if locale.upper() == "CP1252":
            return "cp1252"
        if locale.upper() == "CP1253":
            return "cp1253"
        if locale.upper() == "CP1255":
            return "cp1255"
        if locale.upper() == "CP1256":
            return "cp1256"
        if locale.upper() == "CP1257":
            return "cp1257"
        if locale.upper() == "CP874":
            return "cp874"
        return locale


